package com.example.sufya.draft.recycler_View_Models;

/**
 * Created by sufyan Ahmed on 07/03/2017.
 */

public class card_month_day {
    public String day;
    public String viewAll;

    public card_month_day(String day, String viewAll) {
        this.day = day;
        this.viewAll = viewAll;
    }
}
