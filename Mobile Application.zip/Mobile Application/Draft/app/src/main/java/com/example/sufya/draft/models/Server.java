package com.example.sufya.draft.models;

/**
 * @Author Ajmal, R. (2016).
 * @Website https://www.learn2crack.com/2016/04/android-login-registration-php-mysql-client.html
 */

/**
 *Data model
 */
public class Server {
    private String result;
    private String message;

    public String getResult() {
        return result;
    }

    public String getMessage() {
        return message;
    }

}
